package com.starvpn.app;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.VpnService;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.wireguard.android.backend.Backend;
import com.wireguard.android.backend.GoBackend;
import com.wireguard.android.backend.Tunnel;
import com.wireguard.config.Config;

import java.io.ByteArrayInputStream;
import java.nio.charset.StandardCharsets;
import java.net.URI;
import java.net.URLDecoder;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {
    private static final int VPN_PERMISSION_REQUEST = 701;
    // The URI supplied by the user. Keep private tunnel credentials out of screenshots and logs.
    private static final String WG_URI = "wireguard://6BLcrcy%2F0CvzQRWrtw9QU%2FqUkaKQwULiGu%2BUzIEHGk8%3D@8.6.112.168:934?address=172.16.0.2%2F32%2C2606%3A4700%3A110%3A813a%3A47a6%3A1338%3Af987%3A5919%2F128&presharedkey=&reserved=0%2C0%2C0&publickey=bmXOC%2BF1FxEMF9dyiK2H5%2F1SUtzH0JuVo51h2wPfgyo%3D&mtu=1280#%F0%9F%87%A9%F0%9F%87%AA%20Germany%20%7C%20Frankfurt";

    private final ExecutorService executor = Executors.newSingleThreadExecutor();
    private final Handler handler = new Handler(Looper.getMainLooper());
    private Backend backend;
    private Tunnel tunnel;
    private Config config;
    private TextView statusText, buttonText, timerText, button, detailText;
    private boolean connected = false;
    private boolean busy = false;
    private long connectedAt = 0;

    private final Runnable clockTick = new Runnable() {
        @Override public void run() {
            if (connected) {
                long sec = (System.currentTimeMillis() - connectedAt) / 1000;
                timerText.setText(String.format(java.util.Locale.US, "%02d:%02d:%02d", sec / 3600, (sec / 60) % 60, sec % 60));
                handler.postDelayed(this, 1000);
            }
        }
    };

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(Color.rgb(4, 15, 12));
        getWindow().setNavigationBarColor(Color.rgb(2, 8, 6));
        getWindow().getDecorView().setSystemUiVisibility(0);
        buildUi();
        try {
            backend = new GoBackend(getApplicationContext());
            tunnel = new Tunnel() {
                @Override public String getName() { return "STAR-Germany"; }
                @Override public void onStateChange(State state) {
                    runOnUiThread(() -> setConnected(state == State.UP));
                }
            };
            config = Config.parse(new ByteArrayInputStream(buildWgConfig().getBytes(StandardCharsets.UTF_8)));
        } catch (Exception e) {
            showError("خطا در آماده‌سازی کانفیگ: " + safeMessage(e));
        }
    }

    private void buildUi() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER_HORIZONTAL);
        root.setPadding(dp(24), dp(30), dp(24), dp(24));
        root.setBackground(new GradientDrawable(GradientDrawable.Orientation.TL_BR,
                new int[]{Color.rgb(5, 23, 17), Color.rgb(2, 9, 7), Color.rgb(3, 16, 12)}));
        setContentView(root);

        TextView brand = text("✦  STAR VPN", 34, Color.rgb(35, 232, 147), true);
        brand.setLetterSpacing(0.04f);
        root.addView(brand, matchWrap());
        TextView tagline = text("SECURE  •  PRIVATE  •  SIMPLE", 12, Color.rgb(143, 177, 163), false);
        tagline.setLetterSpacing(0.12f);
        LinearLayout.LayoutParams tagLp = matchWrap(); tagLp.topMargin = dp(7); root.addView(tagline, tagLp);

        View spacer = new View(this); root.addView(spacer, new LinearLayout.LayoutParams(1, dp(42)));
        TextView flag = text("🇩🇪", 42, Color.WHITE, false); root.addView(flag, matchWrap());
        TextView country = text("GERMANY  /  FRANKFURT", 17, Color.WHITE, true);
        country.setLetterSpacing(0.08f); LinearLayout.LayoutParams cLp = matchWrap(); cLp.topMargin = dp(8); root.addView(country, cLp);
        TextView subtitle = text("WireGuard • Secure tunnel", 13, Color.rgb(135, 166, 153), false);
        LinearLayout.LayoutParams sLp = matchWrap(); sLp.topMargin = dp(5); root.addView(subtitle, sLp);

        View gap = new View(this); root.addView(gap, new LinearLayout.LayoutParams(1, dp(40)));
        LinearLayout statusCard = new LinearLayout(this);
        statusCard.setOrientation(LinearLayout.VERTICAL); statusCard.setGravity(Gravity.CENTER);
        statusCard.setPadding(dp(20), dp(22), dp(20), dp(22));
        statusCard.setBackground(round(Color.argb(150, 14, 39, 29), dp(24), Color.argb(90, 48, 116, 83), dp(1)));
        root.addView(statusCard, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(145)));
        statusText = text("DISCONNECTED", 18, Color.rgb(167, 190, 179), true); statusCard.addView(statusText, matchWrap());
        timerText = text("00:00:00", 30, Color.WHITE, true); LinearLayout.LayoutParams tLp = matchWrap(); tLp.topMargin = dp(10); statusCard.addView(timerText, tLp);
        detailText = text("Ready to connect", 12, Color.rgb(130, 163, 148), false); LinearLayout.LayoutParams dLp = matchWrap(); dLp.topMargin = dp(6); statusCard.addView(detailText, dLp);

        View gap2 = new View(this); root.addView(gap2, new LinearLayout.LayoutParams(1, dp(32)));
        button = text("", 18, Color.rgb(2, 25, 16), true);
        button.setGravity(Gravity.CENTER); button.setPadding(dp(16), 0, dp(16), 0);
        button.setBackground(round(Color.rgb(37, 229, 142), dp(20), Color.TRANSPARENT, 0));
        button.setElevation(dp(8)); root.addView(button, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(66)));
        button.setOnClickListener(v -> onMainButton());
        buttonText = button; setButtonLabel("CONNECT");

        TextView foot = text("Your traffic is routed through the selected WireGuard profile. Android will ask you to authorize the VPN connection.", 12, Color.rgb(119, 151, 136), false);
        foot.setGravity(Gravity.CENTER); foot.setLineSpacing(dp(4), 1f);
        LinearLayout.LayoutParams fLp = matchWrap(); fLp.topMargin = dp(24); root.addView(foot, fLp);

        TextView version = text("STAR VPN  •  v1.0.0", 10, Color.rgb(73, 105, 90), true);
        LinearLayout.LayoutParams vLp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        vLp.gravity = Gravity.CENTER_HORIZONTAL; vLp.topMargin = dp(30); root.addView(version, vLp);
    }

    private void onMainButton() {
        if (busy) return;
        if (connected) { disconnect(); return; }
        if (backend == null || config == null) { showError("کانفیگ آماده نیست."); return; }
        Intent prepare = VpnService.prepare(this);
        if (prepare != null) startActivityForResult(prepare, VPN_PERMISSION_REQUEST);
        else connect();
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == VPN_PERMISSION_REQUEST) {
            if (resultCode == RESULT_OK) connect();
            else showError("مجوز VPN داده نشد.");
        }
    }

    private void connect() {
        busy = true; statusText.setText("CONNECTING…"); statusText.setTextColor(Color.rgb(255, 199, 92));
        detailText.setText("Starting WireGuard tunnel"); setButtonLabel("CONNECTING…"); button.setAlpha(0.75f);
        executor.execute(() -> {
            try {
                backend.setState(tunnel, Tunnel.State.UP, config);
                runOnUiThread(() -> { busy = false; button.setAlpha(1f); setConnected(true); });
            } catch (Exception e) {
                runOnUiThread(() -> { busy = false; button.setAlpha(1f); setConnected(false); showError("اتصال برقرار نشد: " + safeMessage(e)); });
            }
        });
    }

    private void disconnect() {
        busy = true; statusText.setText("DISCONNECTING…"); setButtonLabel("PLEASE WAIT");
        executor.execute(() -> {
            try { backend.setState(tunnel, Tunnel.State.DOWN, null); }
            catch (Exception e) { runOnUiThread(() -> showError(safeMessage(e))); }
            runOnUiThread(() -> { busy = false; setConnected(false); });
        });
    }

    private void setConnected(boolean value) {
        connected = value;
        if (value) {
            statusText.setText("CONNECTED"); statusText.setTextColor(Color.rgb(38, 232, 145));
            detailText.setText("WireGuard tunnel is active");
            if (connectedAt == 0) connectedAt = System.currentTimeMillis();
            handler.removeCallbacks(clockTick); handler.post(clockTick);
            button.setBackground(round(Color.rgb(255, 91, 102), dp(20), Color.TRANSPARENT, 0));
            buttonText.setTextColor(Color.WHITE); setButtonLabel("DISCONNECT");
        } else {
            statusText.setText("DISCONNECTED"); statusText.setTextColor(Color.rgb(167, 190, 179));
            detailText.setText("Ready to connect"); connectedAt = 0; handler.removeCallbacks(clockTick); timerText.setText("00:00:00");
            button.setBackground(round(Color.rgb(37, 229, 142), dp(20), Color.TRANSPARENT, 0));
            buttonText.setTextColor(Color.rgb(2, 25, 16)); setButtonLabel("CONNECT");
        }
    }

    private String buildWgConfig() throws Exception {
        URI uri = new URI(WG_URI);
        String privateKey = URLDecoder.decode(uri.getRawUserInfo(), "UTF-8");
        android.net.Uri parsed = android.net.Uri.parse(WG_URI);
        String address = parsed.getQueryParameter("address");
        String publicKey = parsed.getQueryParameter("publickey");
        String psk = parsed.getQueryParameter("presharedkey");
        int mtu = Integer.parseInt(parsed.getQueryParameter("mtu"));
        String endpoint = uri.getHost() + ":" + uri.getPort();
        StringBuilder conf = new StringBuilder();
        conf.append("[Interface]\nPrivateKey = ").append(privateKey).append("\nAddress = ").append(address).append("\nDNS = 1.1.1.1, 1.0.0.1\nMTU = ").append(mtu).append("\n\n");
        conf.append("[Peer]\nPublicKey = ").append(publicKey).append("\nEndpoint = ").append(endpoint).append("\nAllowedIPs = 0.0.0.0/0, ::/0\nPersistentKeepalive = 25\n");
        if (psk != null && !psk.isEmpty()) conf.append("PresharedKey = ").append(psk).append("\n");
        return conf.toString();
    }

    private void showError(String message) {
        Toast.makeText(this, message, Toast.LENGTH_LONG).show();
        detailText.setText("Connection error — check the profile/server");
        statusText.setText("CONNECTION FAILED"); statusText.setTextColor(Color.rgb(255, 116, 116));
        setButtonLabel("RETRY");
    }

    private String safeMessage(Exception e) {
        String m = e.getMessage();
        return (m == null || m.trim().isEmpty()) ? e.getClass().getSimpleName() : m;
    }
    private void setButtonLabel(String s) { buttonText.setText(s); }
    private TextView text(String s, int size, int color, boolean bold) {
        TextView t = new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(color);
        t.setGravity(Gravity.CENTER); t.setTypeface(Typeface.create("sans-serif", bold ? Typeface.BOLD : Typeface.NORMAL)); return t;
    }
    private LinearLayout.LayoutParams matchWrap() { return new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT); }
    private GradientDrawable round(int color, int radius, int strokeColor, int strokeWidth) {
        GradientDrawable d = new GradientDrawable(); d.setColor(color); d.setCornerRadius(radius);
        if (strokeWidth > 0) d.setStroke(strokeWidth, strokeColor); return d;
    }
    private int dp(int v) { return (int)(v * getResources().getDisplayMetrics().density + 0.5f); }
    @Override protected void onDestroy() { super.onDestroy(); handler.removeCallbacks(clockTick); executor.shutdown(); }
}
